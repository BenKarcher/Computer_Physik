#ifndef _H2_H
#define _H2_H

double fext ( double const );

#endif